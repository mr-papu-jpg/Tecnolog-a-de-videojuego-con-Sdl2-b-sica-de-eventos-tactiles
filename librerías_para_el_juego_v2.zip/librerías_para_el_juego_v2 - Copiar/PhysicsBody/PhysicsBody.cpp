#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.h"

#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/colisionsUtils.h"

PhysicsBody::PhysicsBody(float x, float y, float w, float h)
    : rect_{x, y, w, h},
      velocity_{0.0f, 0.0f},
      gravity_(800.0f),
      groundY_(9999.0f),
      grounded_(false)
{}

void PhysicsBody::setVelocity(float vx, float vy) {
    velocity_.x = vx;
    velocity_.y = vy;
}

void PhysicsBody::setGravity(float g) {
    gravity_ = g;
}

void PhysicsBody::setGround(float y) {
    groundY_ = y;
}

bool PhysicsBody::isGrounded() const {
    return grounded_;
}

void PhysicsBody::update(float dt) {
    // 🌌 Aplicar gravedad
    velocity_.y += gravity_ * dt;

    // 🏃 Aplicar movimiento
    rect_.x += velocity_.x * dt;
    rect_.y += velocity_.y * dt;

    // 🧱 Detección de suelo
    if (rect_.y + rect_.h >= groundY_) {
        rect_.y = groundY_ - rect_.h;
        velocity_.y = 0.0f;
        grounded_ = true;
    } else {
        grounded_ = false;
    }
}

void PhysicsBody::constrainToBounds(int screenW, int screenH) {
    if (rect_.x < 0) rect_.x = 0;
    if (rect_.y < 0) rect_.y = 0;
    if (rect_.x + rect_.w > screenW) rect_.x = screenW - rect_.w;
    if (rect_.y + rect_.h > screenH) rect_.y = screenH - rect_.h;
}

float PhysicsBody::getX() const {
    return rect_.x;
}

float PhysicsBody::getY() const {
    return rect_.y;
}

SDL_FPoint PhysicsBody::getVelocity() const {
    return velocity_;
}

bool PhysicsBody::collidesWith(const PhysicsBody& other) const {
    return SDL_HasIntersectionF(&rect_, &other.getRect());
}

const SDL_FRect& PhysicsBody::getRect() const {
    return rect_;
}