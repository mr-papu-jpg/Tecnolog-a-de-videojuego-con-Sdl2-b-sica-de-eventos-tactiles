#pragma once
#include <SDL2/SDL.h>

class PhysicsBody {
public:
    PhysicsBody(float x, float y, float w, float h);

    void setVelocity(float vx, float vy);
    void setGravity(float g);               // ✅ fuerza de gravedad
    void setGround(float y);                // ✅ altura del suelo
    void update(float dt);

    bool isGrounded() const;                // ✅ si está tocando suelo
    void constrainToBounds(int screenW, int screenH); // sigue siendo útil
    const SDL_FRect& getRect() const;
    float getX() const;
    float getY() const;
    SDL_FPoint getVelocity() const;

    bool collidesWith(const PhysicsBody& other) const;

private:
    SDL_FRect rect_;
    SDL_FPoint velocity_;
    float gravity_ = 800.0f;                // valor por defecto
    float groundY_ = 9999.0f;               // suelo muy abajo por defecto
    bool grounded_ = false;
};