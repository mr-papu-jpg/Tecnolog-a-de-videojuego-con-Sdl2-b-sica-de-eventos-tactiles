#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.h"

SpriteAnimator::SpriteAnimator(SDL_Texture* texture)
    : texture_(texture), currentFrameIndex_(0), timer_(0.0f) {}

void SpriteAnimator::addAnimation(const std::string& name, const std::vector<Frame>& frames, bool loop, bool autoPlay) {
    animations_[name] = frames;
    loopingFlags_[name] = loop;
    autoPlayFlags_[name] = autoPlay;
    if (currentAnimation_.empty()) {
        play(name);
    }
    looping_ = loop;
}

void SpriteAnimator::play(const std::string& name) {
    if (animations_.count(name) == 0 || name == currentAnimation_) return;
    currentAnimation_ = name;
    currentFrameIndex_ = 0;
    timer_ = 0.0f;
}

void SpriteAnimator::update(float dt, bool conditionMet) {
    if (animations_.count(currentAnimation_) == 0) return;

    auto& frames = animations_[currentAnimation_];
    if (frames.empty()) return;

    bool autoplay = autoPlayFlags_[currentAnimation_];
    if (!conditionMet && !autoplay) return;

    timer_ += dt;

    // Protección contra duración cero
    float frameDuration = frames[currentFrameIndex_].duration;
    if (frameDuration <= 0.0f) frameDuration = 0.1f;

    if (timer_ >= frameDuration) {
        timer_ -= frameDuration; // ✅ acumula el exceso
        currentFrameIndex_++;

        if (currentFrameIndex_ >= frames.size()) {
            if (loopingFlags_[currentAnimation_]) {
                currentFrameIndex_ = 0;
            } else {
                currentFrameIndex_ = frames.size() - 1;
            }
        }
    }
}

// ✅ NUEVO: versión sin condición
void SpriteAnimator::update(float dt) {
    update(dt, true);
}

void SpriteAnimator::render(SDL_Renderer* renderer, float x, float y) {
    if (!texture_ || animations_.count(currentAnimation_) == 0) return;

    auto& frames = animations_[currentAnimation_];
    if (frames.empty()) return;

    auto& frame = frames[currentFrameIndex_];
    SDL_Rect dst = {
    static_cast<int>(x),
    static_cast<int>(y),
    frame.srcRect.w,
    frame.srcRect.h
};
SDL_RenderCopy(renderer, texture_, &frame.srcRect, &dst);

    
}

const std::string& SpriteAnimator::getCurrentAnimation() const {
    return currentAnimation_;
}

int SpriteAnimator::getCurrentFrameIndex() const {
    return currentFrameIndex_;
}