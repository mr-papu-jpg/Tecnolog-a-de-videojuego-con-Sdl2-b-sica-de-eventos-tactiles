#pragma once
#include <SDL2/SDL.h>
#include <string>
#include <vector>
#include <unordered_map>

struct Frame {
    SDL_Rect srcRect;
    float duration;
};

class SpriteAnimator {
public:
    SpriteAnimator(SDL_Texture* texture);
    
    void addAnimation(const std::string& name, const std::vector<Frame>& frames, bool loop = true, bool autoPlay = false);
    
    void play(const std::string& name);
    void update(float dt, bool conditionMet); // Ejecuta solo si la condición se cumple, o si es autoPlay
    void render(SDL_Renderer* renderer, float x, float y);

    const std::string& getCurrentAnimation() const;
    void update(float dt); // ✅ Nueva declaración
    int getCurrentFrameIndex() const;
    
private:
    SDL_Texture* texture_;
    std::unordered_map<std::string, std::vector<Frame>> animations_;
    std::unordered_map<std::string, bool> loopingFlags_;
    std::unordered_map<std::string, bool> autoPlayFlags_;

    std::string currentAnimation_;
    size_t currentFrameIndex_;
    float timer_;
    bool looping_ = true;
};