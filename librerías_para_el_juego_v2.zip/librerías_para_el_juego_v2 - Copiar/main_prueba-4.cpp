#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <iostream>

#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/EntityTypeSystem/EntityTypeSystem.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/EntityTypeSystem/EntityTypeSystem.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/TouchButton.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/TouchButton.cpp"

int main(int argc, char *argv[])
{
   SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER);
    IMG_Init(IMG_INIT_PNG);
    
    int screenW, screenH;
    // 📱 Obtener tamaño de pantalla del dispositivo
    SDL_DisplayMode dm;
    SDL_GetCurrentDisplayMode(0, &dm);
    screenW = dm.w;
    screenH = dm.h;

SDL_Window* window = SDL_CreateWindow("Demo Joystick + Física + Animación",
    SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, screenW, screenH, SDL_WINDOW_SHOWN);



    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Cargar texturas
    SDL_Surface *playerSurface = IMG_Load("/storage/3807-15EE/DCIM/frames/gato caminando.png");
    SDL_Texture *playerTexture = SDL_CreateTextureFromSurface(renderer, playerSurface);
    SDL_FreeSurface(playerSurface);

    SDL_Surface *ringSurface = IMG_Load("/storage/3807-15EE/DCIM/frames/joystickRing.png");
    SDL_Texture *ringTexture = SDL_CreateTextureFromSurface(renderer, ringSurface);
    SDL_FreeSurface(ringSurface);

    SDL_Surface *knobSurface = IMG_Load("/storage/3807-15EE/DCIM/frames/JoystickKnob.png");
    SDL_Texture *knobTexture = SDL_CreateTextureFromSurface(renderer, knobSurface);
    SDL_FreeSurface(knobSurface);

    // Configurar joystick
    TouchJoystick joystick;
    joystick.setTextures(ringTexture, knobTexture);
    joystick.setPosition(screenW * 0.255f, screenH * 0.75f, screenW * 0.22f); // posición inferior izquierda
    joystick.setScreenSize(screenW, screenH - 100);
    SDL_Surface *fireSurface = IMG_Load("/storage/3807-15EE/DCIM/frames/ButtonShoot.png");
    SDL_Texture *fireTexture = SDL_CreateTextureFromSurface(renderer, fireSurface);
    SDL_FreeSurface(fireSurface);

    TouchButton fireButton;
    fireButton.set(fireTexture, screenW * 0.7f, screenH * 0.7f, 64 * 3, 64 * 3); // ejemplo
    fireButton.setScreenSize(screenW, screenH - 100);

    // Crear entidad jugador
    Entity player(100, 100, 64, 64, playerTexture, EntityType::Player);
    player.setGround(screenH * 0.76f);
    player.setGravity(800);

    // Configurar animación del jugador
    std::vector<Frame> idleFrames = {
        {{0, 0, 64, 64}, 0.2f}};

    player.getAnimator().addAnimation("idle", idleFrames, true, false);

    std::vector<Frame> runFrames = {
        {{0, 0, 64, 64}, 0.125f},
        {{64, 0, 64, 64}, 0.125f},
        {{128, 0, 64, 64}, 0.125f},
        {{192, 0, 64, 64}, 0.125f}};
    player.getAnimator().addAnimation("run", runFrames, true, false); // autoPlay = false
    player.getAnimator().play("run");

    SDL_Surface *bulletSurface = IMG_Load("/storage/3807-15EE/DCIM/frames/spritesheetBolaRoja.png");
    if (!bulletSurface)
    {
        SDL_Log("Error al cargar bulletSurface: %s", IMG_GetError());
        return 1;
    }
    SDL_Texture *bulletTexture = SDL_CreateTextureFromSurface(renderer, bulletSurface);
    SDL_FreeSurface(bulletSurface);
    if (!bulletTexture)
    {
        SDL_Log("Error al crear bulletTexture: %s", SDL_GetError());
        return 1;
    }
    Entity bullet(100, 100, 64, 64, bulletTexture, EntityType::Projectile);
    bullet.setVelocity(300.0f, 0.0f); // velocidad hacia la derecha

    bullet.setGravity(0.0f); // sin gravedad

    bullet.setGround(99999.0f); // no necesita s
    
    std::vector<Entity> bullets;
    
    std::vector<Frame> bulletFrames = {
        {{0, 0, 64, 64}, 0.1f}};
    bullet.getAnimator().addAnimation("fly", bulletFrames, true, true);

    player.getAnimator().addAnimation("idle", idleFrames, true, false);

    bool running = true;
    Uint32 lastTick = SDL_GetTicks();

    while (running)
    {
        Uint32 currentTick = SDL_GetTicks();
        float deltaTime = (currentTick - lastTick) / 1000.0f;
        lastTick = currentTick;

        SDL_Event event;
        // 1. Procesar eventos
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
                running = false;
            joystick.handleEvent(event, renderer);
            fireButton.handleEvent(event);
        }

        // 2. Actualizar joystick
        joystick.update(deltaTime);

        // 3. Obtener dirección y aplicar movimiento
        SDL_FPoint dir = joystick.getDirectionF();
        float moveSpeed = 200.0f;
        player.applyJoystickInput(dir, moveSpeed);

        bool isMoving = std::abs(dir.x) > 0.1f;
        float vx = dir.x * moveSpeed;
        float vy = player.getVelocity().y;

        // 4. Evaluar salto
        if (dir.y < -0.5f && player.isGrounded())
        {
            vy = -600.0f;
        }

        // 5. Aplicar velocidad
        player.setVelocity(vx, vy);

        // 6. Evaluar disparo (ahora después del update del joystick)
        if (fireButton.isPressed())
        {
            std::cout << "Disparo detectado\n";
            Entity bullet(player.getRect().x + player.getRect().w,
                          player.getRect().y + player.getRect().h / 2 - 8,
                          16, 16, bulletTexture, EntityType::Projectile);

            bullet.setVelocity(300.0f, 0.0f);
            bullet.setGravity(0.0f);
            bullet.setGround(9999.0f);

            bullet.getAnimator().addAnimation("fly", bulletFrames, true, true);
            bullet.getAnimator().play("fly");

            bullets.push_back(bullet);
            fireButton.reset(); // puedes mover esto al final del frame si sigue fallando
        }

        joystick.update(deltaTime);

        // Cambiar animación según estado
        std::string currentAnim = player.getAnimator().getCurrentAnimation();
        if (isMoving && currentAnim != "run")
        {
            player.getAnimator().play("run");
        }
        else if (!isMoving && currentAnim != "idle")
        {
            player.getAnimator().play("idle");
        }

        if (dir.y < -0.5f && player.isGrounded())
        {
            vy = -600.0f; // impulso vertical
        }

        // ⚙️ Aplicar velocidad total
        player.setVelocity(vx, vy);

        // Actualizar animador solo si debe animar
        player.getAnimator().update(deltaTime, true);

        player.update(deltaTime);
        for (auto &b : bullets)
        {
            b.update(deltaTime);
        }
        bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
                                     [screenW](const Entity &b) {
                                         return b.getRect().x > screenW || b.getTraits().getTag() == "Consumed";
                                     }),
                      bullets.end());

        // Render
        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_RenderClear(renderer);

        player.render(renderer);
        for (auto &b : bullets)
        {
            b.render(renderer);
        }
        joystick.render(renderer);

        fireButton.render(renderer);
        SDL_RenderPresent(renderer);
    }

    // Cleanup
    SDL_DestroyTexture(playerTexture);
    SDL_DestroyTexture(ringTexture);
    SDL_DestroyTexture(knobTexture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return 0;
}