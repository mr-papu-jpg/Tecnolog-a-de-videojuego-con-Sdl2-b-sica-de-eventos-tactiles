#pragma once
#include <vector>
#include <string>

// Estructura para representar cada equipo
struct Equipment {
    std::string name;
    int bonusAttack;
    int bonusDefense;
};

// Estructura que contiene todo lo necesario para mostrar el inventario
struct InventoryDisplayData {
    int level;
    int hp;
    int magic;
    int attack;
    int defense;
    int determination;
    int evilness;
    int goodness;
    int killCount;
    int deathCount;
    int escapeCount;
    std::vector<Equipment> equippedItems;
    std::vector<std::string> discoveredZones;
};

class PlayerStats; // Declaración anticipada

class InventorySystem {
public:
    InventoryDisplayData getDisplayData(const PlayerStats& stats) const;

    void setEquippedItems(const std::vector<Equipment>& items);
    void setDiscoveredZones(const std::vector<std::string>& zones);

private:
    std::vector<Equipment> equippedItems;
    std::vector<std::string> discoveredZones;
};