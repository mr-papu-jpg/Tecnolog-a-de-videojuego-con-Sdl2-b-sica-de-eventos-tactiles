#include "InventorySystem.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PlayerStats/PlayerStats.h"

InventoryDisplayData InventorySystem::getDisplayData(const PlayerStats& stats) const {
    InventoryDisplayData data;
    data.level = stats.level;
    data.hp = stats.hp;
    data.magic = stats.magic;
    data.attack = stats.attack;
    data.defense = stats.defense;
    data.determination = stats.determination;
    data.evilness = stats.evilness;
    data.goodness = stats.goodness;
    data.killCount = stats.killCount;
    data.deathCount = stats.deathCount;
    data.escapeCount = stats.escapeCount;
    data.equippedItems = equippedItems;
    data.discoveredZones = discoveredZones;

    return data;
}

void InventorySystem::setEquippedItems(const std::vector<Equipment>& items) {
    equippedItems = items;
}

void InventorySystem::setDiscoveredZones(const std::vector<std::string>& zones) {
    discoveredZones = zones;
}