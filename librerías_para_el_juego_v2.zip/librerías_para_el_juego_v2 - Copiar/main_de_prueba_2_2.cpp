#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.cpp"

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_EVENTS | SDL_INIT_GAMECONTROLLER);
    IMG_Init(IMG_INIT_PNG);

    SDL_DisplayMode mode;
    SDL_GetCurrentDisplayMode(0, &mode);

    SDL_Window* window = SDL_CreateWindow("Motor de Prueba",
                                          SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                          mode.w, mode.h, SDL_WINDOW_FULLSCREEN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // 🎨 Cargar texturas
    SDL_Texture* spriteSheet = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/Untitled 07-11-2025 05-48-37.png");
    SDL_Texture* ringTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/joystickRing.png");
    SDL_Texture* knobTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/JoystickKnob.png");

    if (!spriteSheet || !ringTex || !knobTex) {
        SDL_Log("❌ Error cargando texturas");
        return 1;
    }

    // 🎮 Configurar joystick
    TouchJoystick joystick;
    joystick.setTextures(ringTex, knobTex);
    joystick.setPosition(mode.w * 0.125f, mode.h * 0.85f, mode.h * 0.08f);
    joystick.setScreenSize(mode.w, mode.h);

    // 🧍 Crear entidad y animaciones
    Entity player(mode.w / 2 - 32, mode.h / 2 - 32, 64, 64, spriteSheet);
    player.animator().addAnimation("idle", { { {0, 0, 64, 64}, 0.3f } });
    player.animator().addAnimation("run", {
        { {  0, 0, 64, 64 }, 0.1f },
        { { 64, 0, 64, 64 }, 0.1f },
        { {128, 0, 64, 64 }, 0.1f },
        { {192, 0, 64, 64 }, 0.1f },
        { {256, 0, 64, 64 }, 0.1f },
        { {320, 0, 64, 64 }, 0.1f },
        { {384, 0, 64, 64 }, 0.1f }
    });
    player.animator().addAnimation("jump", {
    { {0, 0, 64, 64}, 0.3f } // mismo que "idle"
});
    player.playAnimation("idle");

    // ⚙️ Física
    PhysicsBody physics(player.rect().x, player.rect().y, player.rect().w, player.rect().h);
    physics.setGravity(900.0f);
    physics.setGround(mode.h * 0.95f);

    Uint32 lastTicks = SDL_GetTicks();
    bool running = true;

    while (running) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) running = false;
            joystick.handleEvent(event, renderer);
        }

        Uint32 currentTicks = SDL_GetTicks();
        float deltaTime = (currentTicks - lastTicks) / 1000.0f;
        lastTicks = currentTicks;

        joystick.update(deltaTime);

        SDL_FPoint input = joystick.getDirectionF();
        float speed = 200.0f;

        // 🏃 Movimiento horizontal
        // 🏃 Mantener velocidad horizontal
float vx = input.x * speed;
float vy = physics.getVelocity().y;

// 🧗 Si se detecta salto
if (input.y < -0.5f && physics.isGrounded()) {
    vy = -600.0f; // impulso vertical
}

// ⚙️ Aplicar velocidad total
physics.setVelocity(vx, vy);

        physics.update(deltaTime);
        player.rect().x = physics.getX();
        player.rect().y = physics.getY();

        bool isMoving = (std::abs(input.x) > 0.1f);
        player.update(deltaTime, isMoving, physics);

        // 🧪 Debug
        SDL_Log("Pos: %.1f, %.1f | Grounded: %s | Anim: %s",
                player.rect().x, player.rect().y,
                physics.isGrounded() ? "true" : "false",
                player.animator().getCurrentAnimation().c_str());

        // 🎨 Render
        SDL_SetRenderDrawColor(renderer, 40, 40, 60, 255);
        SDL_RenderClear(renderer);
        joystick.render(renderer);
        player.render(renderer);

        // 🧱 Dibujar suelo
        SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
        SDL_RenderDrawLine(renderer, 0, (int)mode.h * 0.95f, mode.w, (int)mode.h * 0.95f);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyTexture(spriteSheet);
    SDL_DestroyTexture(ringTex);
    SDL_DestroyTexture(knobTex);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return 0;
}