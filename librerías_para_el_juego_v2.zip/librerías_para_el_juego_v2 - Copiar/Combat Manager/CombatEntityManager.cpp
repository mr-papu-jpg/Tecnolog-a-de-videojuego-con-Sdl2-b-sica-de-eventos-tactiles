#include "CombatEntityManager.h"
#include "StoryFlags.h"

CombatEntityManager::CombatEntityManager(std::shared_ptr<CombatManager> combatMgr,
                                         std::shared_ptr<StoryFlags> storyFlags)
    : combatManager_(combatMgr), storyFlags_(storyFlags) {}

void CombatEntityManager::handleCombat() {
    const auto& entities = getEntities();

    for (size_t i = 0; i < entities.size(); ++i) {
        for (size_t j = i + 1; j < entities.size(); ++j) {
            auto& a = entities[i];
            auto& b = entities[j];

            if (a->checkCollisionWith(*b)) {
                bool aCombat = a->traits().isCombat();
                bool bCombat = b->traits().isCombat();

                if (aCombat && bCombat) {
                    combatManager_->processAttack(a, b);

                    if (b->traits().isNPC() && !b->traits().isHostile()) {
                        // ⚠️ Registrar muerte de NPC inocente si su estado lo indica
                        if (b->traits().getTag() == "Defeated" || b->traits().getHealth() <= 0) {
                            storyFlags_->setFlag("KilledInnocentNPC");
                        }
                    }

                } else if (aCombat || bCombat) {
                    combatManager_->processEnvironmentalContact(a, b);
                }
            }
        }
    }
}

void CombatEntityManager::applyEthicalConsequences() {
    if (storyFlags_->isFlagSet("KilledInnocentNPC")) {
        // 🧠 Aquí podrías condicionar cambios en el mundo o desbloquear eventos oscuros
        storyFlags_->setFlag("EthicsRouteLocked_Benevolent");
        storyFlags_->setFlag("TriggeredGuiltDialog");

        // Esta parte puede integrarse con moralSystem, AbilitySystem o incluso SaveManager
    }

    // 🧭 Puedes añadir más reglas:
    if (storyFlags_->isFlagSet("KilledBossNPC")) {
        storyFlags_->setFlag("OpenedDarkEndingBranch");
    }
}

void CombatEntityManager::updateCombatStates(float dt) {
    for (auto& entity : getEntities()) {
        if (entity->traits().isCombat()) {
            combatManager_->updateEntityState(entity, dt);
        }
    }
}