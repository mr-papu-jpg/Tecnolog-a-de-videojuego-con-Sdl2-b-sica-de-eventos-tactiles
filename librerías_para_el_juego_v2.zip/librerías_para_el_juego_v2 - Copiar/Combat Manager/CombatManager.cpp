#include "combatManager.h"
#include <algorithm>

namespace Combat {

    int CombatManager::calculateDamage(const CombatStats& attacker, const CombatStats& defender, DamageType type) {
        switch (type) {
            case DamageType::Physical:
                return std::max(1, attacker.atq - defender.def / 2);
            case DamageType::Magical:
                return std::max(1, attacker.mag - defender.mag / 3);
            case DamageType::TrueDamage:
                return std::max(1, attacker.atq); // Ignora defensa
            default:
                return 0;
        }
    }

    int CombatManager::calculateHealing(const CombatStats& healer, int basePower) {
        return basePower + healer.mag / 2;
    }

    int CombatManager::regenerateMP(const CombatStats& entity, bool grazed, bool fullHit) {
        if (grazed) return 8;
        if (fullHit) return 5;
        return 0;
    }

}