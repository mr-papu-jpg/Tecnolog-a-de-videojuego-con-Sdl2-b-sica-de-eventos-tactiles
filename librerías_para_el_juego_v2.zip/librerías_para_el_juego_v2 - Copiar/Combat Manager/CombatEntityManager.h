#pragma once
#include <memory>
#include <vector>
#include "CombatManager.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/EntityManager.h"

class CombatEntityManager : public EntityManager {
public:
    CombatEntityManager(std::shared_ptr<CombatManager> combatMgr);
    
    void handleCombat();                  // Combate basado en colisiones
    void applyEthicalConsequences();      // Futuro: modifica StoryFlags, rutas éticas
    void updateCombatStates(float dt);    // Para efectos como regeneración o buffs

private:
    std::shared_ptr<CombatManager> combatManager_;
};