#ifndef COMBAT_MANAGER_H
#define COMBAT_MANAGER_H

namespace Combat {

    enum class DamageType {
        Physical,
        Magical,
        TrueDamage
    };

    struct CombatStats {
        int hp;
        int mp;
        int atq;
        int def;
        int mag;
    };

    class CombatManager {
    public:
        static int calculateDamage(const CombatStats& attacker, const CombatStats& defender, DamageType type);
        static int calculateHealing(const CombatStats& healer, int basePower);
        static int regenerateMP(const CombatStats& entity, bool grazed = false, bool fullHit = true);
    };

}

#endif