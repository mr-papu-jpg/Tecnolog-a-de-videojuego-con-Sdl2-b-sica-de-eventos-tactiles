#pragma once
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Save programs/json.hpp"

class PlayerStats {
public:
    int level = 1;
    int maxHP = 100;
    int currentHP = 100;
    int exp = 0;
    int expToNextLevel = 100;

    int attack = 10;
    int defense = 5;
    int magic = 8;
    int determination = 20;

    int goodnessLevel = 0;
    int evilnessLevel = 0;

    PlayerStats() = default;

    void gainExp(int amount);
    void takeDamage(int amount);
    void heal(int amount);

    void increaseGoodness(int amount);
    void increaseEvilness(int amount);

    nlohmann::json toJson() const;
    void fromJson(const nlohmann::json& j);
};