#include "PlayerStats.h"

void PlayerStats::gainExp(int amount) {
    exp += amount;
    while (exp >= expToNextLevel) {
        exp -= expToNextLevel;
        level++;
        maxHP += 20;
        attack += 2;
        defense += 1;
        magic += 2;
        determination += 3;
        currentHP = maxHP;
        expToNextLevel += 50;
    }
}

void PlayerStats::takeDamage(int amount) {
    int reducedDamage = amount - defense;
    if (reducedDamage < 1) reducedDamage = 1;
    currentHP -= reducedDamage;
    if (currentHP < 0) currentHP = 0;
}

void PlayerStats::heal(int amount) {
    currentHP += amount;
    if (currentHP > maxHP) currentHP = maxHP;
}

void PlayerStats::increaseGoodness(int amount) {
    goodnessLevel += amount;
    if (goodnessLevel > 100) goodnessLevel = 100;
}

void PlayerStats::increaseEvilness(int amount) {
    evilnessLevel += amount;
    if (evilnessLevel > 100) evilnessLevel = 100;
}

nlohmann::json PlayerStats::toJson() const {
    return {
        {"level", level},
        {"maxHP", maxHP},
        {"currentHP", currentHP},
        {"exp", exp},
        {"expToNextLevel", expToNextLevel},
        {"attack", attack},
        {"defense", defense},
        {"magic", magic},
        {"determination", determination},
        {"goodnessLevel", goodnessLevel},
        {"evilnessLevel", evilnessLevel}
    };
}

void PlayerStats::fromJson(const nlohmann::json& j) {
    level = j.value("level", 1);
    maxHP = j.value("maxHP", 100);
    currentHP = j.value("currentHP", 100);
    exp = j.value("exp", 0);
    expToNextLevel = j.value("expToNextLevel", 100);
    attack = j.value("attack", 10);
    defense = j.value("defense", 5);
    magic = j.value("magic", 8);
    determination = j.value("determination", 20);
    goodnessLevel = j.value("goodnessLevel", 0);
    evilnessLevel = j.value("evilnessLevel", 0);
}