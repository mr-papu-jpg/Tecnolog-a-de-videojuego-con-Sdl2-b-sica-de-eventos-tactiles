#pragma once
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Save programs/json.hpp"

nlohmann::json toJson() const;
void fromJson(const nlohmann::json& j);

enum class EthicalRoute {
    GOOD,
    EVIL,
    NEUTRAL,
    DETERMINED
};

struct Ability {
    std::string name;
    EthicalRoute route;
    bool unlocked = false;
    bool active = false;
    bool permanentlyLocked = false; // Si el jugador perdió la oportunidad
};

class AbilitySystem {
public:
    void setRoute(EthicalRoute newRoute);
    void unlockAbility(const std::string& name);
    void lockAbilityPermanently(const std::string& name);
    bool isAbilityActive(const std::string& name) const;
    void updateAbilities();

private:
    EthicalRoute currentRoute;
    std::vector<Ability> abilities;
};