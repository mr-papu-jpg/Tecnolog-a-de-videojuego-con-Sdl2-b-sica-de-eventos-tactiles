#pragma once
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Save programs/json.hpp"
using json = nlohmann::json;

json AbilitySystem::toJson() const {
    json j;
    for (const auto& ability : abilities) {
        j.push_back({
            {"name", ability.name},
            {"route", static_cast<int>(ability.route)},
            {"unlocked", ability.unlocked},
            {"active", ability.active},
            {"permanentlyLocked", ability.permanentlyLocked}
        });
    }
    return j;
}

void AbilitySystem::fromJson(const json& j) {
    abilities.clear();
    for (const auto& item : j) {
        Ability ability;
        ability.name = item.value("name", "");
        ability.route = static_cast<EthicalRoute>(item.value("route", 0));
        ability.unlocked = item.value("unlocked", false);
        ability.active = item.value("active", false);
        ability.permanentlyLocked = item.value("permanentlyLocked", false);
        abilities.push_back(ability);
    }
}

void AbilitySystem::setRoute(EthicalRoute newRoute) {
    currentRoute = newRoute;
    updateAbilities();
}

void AbilitySystem::unlockAbility(const std::string& name) {
    for (auto& ability : abilities) {
        if (ability.name == name) {
            ability.unlocked = true;
            if (ability.route == currentRoute && !ability.permanentlyLocked) {
                ability.active = true;
            }
            return;
        }
    }

    // Si no existe, agregarla
    abilities.push_back({name, currentRoute, true, true, false});
}

void AbilitySystem::lockAbilityPermanently(const std::string& name) {
    for (auto& ability : abilities) {
        if (ability.name == name) {
            ability.permanentlyLocked = true;
            ability.active = false;
            return;
        }
    }
}

bool AbilitySystem::isAbilityActive(const std::string& name) const {
    for (const auto& ability : abilities) {
        if (ability.name == name) {
            return ability.active;
        }
    }
    return false;
}

void AbilitySystem::updateAbilities() {
    for (auto& ability : abilities) {
        if (ability.route == currentRoute && ability.unlocked && !ability.permanentlyLocked) {
            ability.active = true;
        } else {
            ability.active = false;
        }
    }
}