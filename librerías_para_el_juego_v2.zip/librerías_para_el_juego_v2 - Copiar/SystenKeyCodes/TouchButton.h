#pragma once
#include <SDL2/SDL.h>

class TouchButton {
public:
    TouchButton();

    void set(SDL_Texture* tex, float x, float y, float w, float h);
    void setScreenSize(int w, int h);
    void handleEvent(const SDL_Event& e);
    void render(SDL_Renderer* renderer);

    bool isPressed() const;
    void reset();

private:
    SDL_FRect rect_;
    SDL_Texture* texture_;
    bool pressed_;
    int activeFingerId_; // ID del dedo que controla el botón
    int screenW_, screenH_; // Tamaño de pantalla para convertir coordenadas
};