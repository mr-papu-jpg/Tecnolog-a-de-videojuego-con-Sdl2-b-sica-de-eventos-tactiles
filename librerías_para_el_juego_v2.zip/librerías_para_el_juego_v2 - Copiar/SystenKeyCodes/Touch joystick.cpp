#include "Touch joystick.h"
#include <cmath>

TouchJoystick::TouchJoystick()
    : ringTex_(nullptr), knobTex_(nullptr),
      center_{0, 0}, knobPos_{0, 0}, direction_{0, 0},
      radius_(100.0f), active_(false),
      fingerId_(-1), screenW_(800), screenH_(600)
{}

void TouchJoystick::setTextures(SDL_Texture* ring, SDL_Texture* knob) {
    ringTex_ = ring;
    knobTex_ = knob;
}

void TouchJoystick::setPosition(float x, float y, float radius) {
    center_.x = x;
    center_.y = y;
    radius_ = radius;
    knobPos_ = center_;
}

void TouchJoystick::setScreenSize(int w, int h) {
    screenW_ = w;
    screenH_ = h;
}

void TouchJoystick::handleEvent(const SDL_Event& event, SDL_Renderer* renderer) {
    if (event.type != SDL_FINGERDOWN &&
        event.type != SDL_FINGERMOTION &&
        event.type != SDL_FINGERUP) return;

    float touchX = event.tfinger.x * screenW_;
    float touchY = event.tfinger.y * screenH_;

    float dx = touchX - center_.x;
    float dy = touchY - center_.y;
    float dist = std::sqrt(dx * dx + dy * dy);

    if (event.type == SDL_FINGERDOWN && dist <= radius_) {
        active_ = true;
        fingerId_ = event.tfinger.fingerId;
    }
    else if (event.type == SDL_FINGERMOTION && active_ && event.tfinger.fingerId == fingerId_) {
        if (dist > radius_) {
            dx *= radius_ / dist;
            dy *= radius_ / dist;
        }

        knobPos_.x = center_.x + dx;
        knobPos_.y = center_.y + dy;

        direction_.x = dx / radius_;
        direction_.y = dy / radius_;
    }
    else if (event.type == SDL_FINGERUP && active_ && event.tfinger.fingerId == fingerId_) {
        active_ = false;
        direction_ = {0, 0};
        knobPos_ = center_;
        fingerId_ = -1;
    }
}

void TouchJoystick::update(float dt) {
    if (!active_) {
        float speed = 500.0f;
        float dx = center_.x - knobPos_.x;
        float dy = center_.y - knobPos_.y;
        float dist = std::sqrt(dx * dx + dy * dy);

        if (dist > 1.0f) {
            float step = speed * dt;
            if (step > dist) step = dist;

            knobPos_.x += dx / dist * step;
            knobPos_.y += dy / dist * step;
        } else {
            knobPos_ = center_;
        }
    }
}

void TouchJoystick::render(SDL_Renderer* renderer) {
    if (!ringTex_ || !knobTex_) return;

    SDL_Rect ringRect = {
        static_cast<int>(center_.x - radius_),
        static_cast<int>(center_.y - radius_),
        static_cast<int>(radius_ * 2),
        static_cast<int>(radius_ * 2)
    };

    SDL_Rect knobRect = {
        static_cast<int>(knobPos_.x - radius_ / 2),
        static_cast<int>(knobPos_.y - radius_ / 2),
        static_cast<int>(radius_),
        static_cast<int>(radius_)
    };

    SDL_RenderCopy(renderer, ringTex_, nullptr, &ringRect);
    SDL_RenderCopy(renderer, knobTex_, nullptr, &knobRect);
}

SDL_FPoint TouchJoystick::getDirectionF() const {
    return direction_;
}

SDL_Point TouchJoystick::getDirection() const {
    return {
        (std::abs(direction_.x) > 0.1f ? (direction_.x > 0 ? 1 : -1) : 0),
        (std::abs(direction_.y) > 0.1f ? (direction_.y > 0 ? 1 : -1) : 0)
    };
}