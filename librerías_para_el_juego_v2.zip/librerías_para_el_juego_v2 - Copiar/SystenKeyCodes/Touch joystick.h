#pragma once
#include <SDL2/SDL.h>

class TouchJoystick {
public:
    TouchJoystick();

    void setTextures(SDL_Texture* ring, SDL_Texture* knob);
    void setPosition(float x, float y, float radius);
    void setScreenSize(int w, int h);

    void handleEvent(const SDL_Event& event, SDL_Renderer* renderer);
    void update(float dt);
    void render(SDL_Renderer* renderer);

    SDL_FPoint getDirectionF() const;
    SDL_Point getDirection() const;

private:
    SDL_Texture* ringTex_;
    SDL_Texture* knobTex_;
    SDL_FPoint center_;
    SDL_FPoint knobPos_;
    SDL_FPoint direction_;
    float radius_;
    bool active_;
    SDL_FingerID fingerId_;
    int screenW_, screenH_;
};