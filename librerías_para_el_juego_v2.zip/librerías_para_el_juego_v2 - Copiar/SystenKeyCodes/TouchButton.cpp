#include "TouchButton.h"

TouchButton::TouchButton()
    : rect_{0, 0, 64, 64},
      texture_{nullptr},
      pressed_{false},
      activeFingerId_{-1},
      screenW_{1}, screenH_{1} // evitar división por cero
{}

// Establece textura y posición del botón
void TouchButton::set(SDL_Texture* tex, float x, float y, float w, float h) {
    texture_ = tex;
    rect_ = {x, y, w, h};
}

// Establece tamaño de pantalla para convertir coordenadas táctiles
void TouchButton::setScreenSize(int w, int h) {
    screenW_ = w;
    screenH_ = h;
}

void TouchButton::handleEvent(const SDL_Event& event) {
    if (event.type == SDL_FINGERDOWN || event.type == SDL_FINGERMOTION) {
        if (event.type == SDL_FINGERMOTION && event.tfinger.fingerId != activeFingerId_)
    return; // ignorar movimiento de dedos no activos

        float x = event.tfinger.x * screenW_;
        float y = event.tfinger.y * screenH_;

        // Verifica si el toque está dentro del rectángulo
        if (x >= rect_.x && x <= rect_.x + rect_.w &&
            y >= rect_.y && y <= rect_.y + rect_.h) {
            
            pressed_ = true;
            activeFingerId_ = event.tfinger.fingerId;
        }
    } else if (event.type == SDL_FINGERUP) {
        if (event.tfinger.fingerId == activeFingerId_) {
            pressed_ = false;
            activeFingerId_ = -1;
        }
    }
}

void TouchButton::render(SDL_Renderer* renderer) {
    if (texture_) {
        SDL_Rect dst = {
            static_cast<int>(rect_.x),
            static_cast<int>(rect_.y),
            static_cast<int>(rect_.w),
            static_cast<int>(rect_.h)
        };
        SDL_RenderCopy(renderer, texture_, nullptr, &dst);
    }
}

bool TouchButton::isPressed() const {
    return pressed_;
}

void TouchButton::reset() {
    pressed_ = false;
    activeFingerId_ = -1;
}