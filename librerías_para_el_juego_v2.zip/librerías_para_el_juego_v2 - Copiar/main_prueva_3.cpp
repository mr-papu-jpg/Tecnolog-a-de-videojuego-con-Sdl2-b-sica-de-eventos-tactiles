#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/EntityManager.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/EntityManager.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/EntityTypeSystem/EntityTypeSystem.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/EntityTypeSystem/EntityTypeSystem.cpp"


// 🪟 Ventana principal
SDL_Window* window = nullptr;

// 🎨 Renderizador
SDL_Renderer* renderer = nullptr;

// 📐 Resolución de pantalla
int screenW = 0, screenH = 0;

// 🎮 Joystick táctil
TouchJoystick joystick;

// 🧠 Sistema de entidades
EntityManager manager;


bool initSDL(SDL_Window*& window, SDL_Renderer*& renderer, int screenW, int screenH) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER ) < 0) {
        SDL_Log("❌ SDL_Init falló: %s", SDL_GetError());
        return false;
    }

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        SDL_Log("❌ IMG_Init falló: %s", IMG_GetError());
        return false;
    }

    SDL_DisplayMode dm;
    if (SDL_GetCurrentDisplayMode(0, &dm) != 0) {
        SDL_Log("❌ No se pudo obtener resolución de pantalla: %s", SDL_GetError());
        return false;
    }

    // ⚠️ Ya no se redeclaran, solo se asignan:
    screenW = dm.w;
    screenH = dm.h;

    window = SDL_CreateWindow("Prueba del motor", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, screenW, screenH, SDL_WINDOW_SHOWN);
    if (!window) {
        SDL_Log("❌ Error al crear la ventana: %s", SDL_GetError());
        return false;
    }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        SDL_Log("❌ Error al crear el renderer: %s", SDL_GetError());
        return false;
    }

    return true;
}

int main() {
    bool running = true;
    int screenW, screenH;
if (!initSDL(window, renderer, screenW, screenH)) return 1;

    // 📱 Obtener tamaño de pantalla del dispositivo
    SDL_DisplayMode dm;
    SDL_GetCurrentDisplayMode(0, &dm);
    screenW = dm.w;
    screenH = dm.h;

    // 🎮 Joystick táctil
    extern TouchJoystick joystick;
    SDL_Texture* ringTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/joystickRing.png");
    if (!ringTex) {
    SDL_Log("❌ Error al cargar texturas del joystick.");
    running = false;
}

    SDL_Texture* knobTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/JoystickKnob.png");
    if (!knobTex) {
    SDL_Log("❌ Error al cargar texturas del joystick.");
    running = false;
}
    
    joystick.setTextures(ringTex, knobTex);   joystick.setPosition(screenW * 0.255f, screenH * 0.75f, screenW * 0.22f); // posición inferior izquierda
    joystick.setScreenSize(screenW, screenH);

    // 🧍 Cargar jugador
    SDL_Texture* playerTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/Untitled 07-11-2025 05-48-37.png");
    if (!playerTex) {
    SDL_Log("❌ Error al cargar textura del jugador.");
    running = false;
    }
    
    if (!playerTex || !ringTex || !knobTex) {
        SDL_Log("❌ Una de las texturas no se cargó correctamente.");
        return 1;
    }

    auto player = std::make_shared<Entity>(screenW / 2 - 32, screenH / 2 - 32, 64, 64, playerTex, EntityType::Player);
        player->animator().addAnimation("idle", { { {0, 0, 64, 64}, 0.3f } });
    player->animator().addAnimation("run", { { {  0, 0, 64, 64 }, 0.1f },
        { { 64, 0, 64, 64 }, 0.1f },
        { {128, 0, 64, 64 }, 0.1f },
        { {192, 0, 64, 64 }, 0.1f },
        { {256, 0, 64, 64 }, 0.1f },
        { {320, 0, 64, 64 }, 0.1f },
        { {384, 0, 64, 64 }, 0.1f } });
    player->animator().addAnimation("jump", {
    { {0, 0, 64, 64}, 0.3f } // mismo que "idle"
});
    player->playAnimation("idle");
    // Enemigo estático
    auto enemy = std::make_shared<Entity>(screenW * 0.75f, screenH * 0.65f, 64, 64, playerTex, EntityType::Enemy);
    EntityManager manager;
    manager.addEntity(player);
    manager.addEntity(enemy);
    
     // ⚙️ Física
    PhysicsBody physics(player->rect().x, player->rect().y, player->rect().w, player->rect().h);
    physics.setGravity(900.0f);
    physics.setGround(screenH * 0.76f);

   
    Uint32 lastTick = SDL_GetTicks();

    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = false;
            joystick.handleEvent(e, renderer);
        }

        Uint32 currentTick = SDL_GetTicks();
        float deltaTime = (currentTick - lastTick) / 1000.0f;
        lastTick = currentTick;
        
        joystick.update(deltaTime);

        // 📍 Movimiento táctil
        SDL_FPoint input = joystick.getDirectionF();
        SDL_Log("Joystick dir: %.2f, %.2f", input.x, input.y); // Debug: ver si está moviendo
         float speed = 200.0f;

        // 🏃 Movimiento horizontal
        // 🏃 Mantener velocidad horizontal
float vx = input.x * speed;
float vy = physics.getVelocity().y;

// 🧗 Si se detecta salto
if (input.y < -0.5f && physics.isGrounded()) {
    vy = -600.0f; // impulso vertical
}

// ⚙️ Aplicar velocidad total
physics.setVelocity(vx, vy);

        physics.update(deltaTime);
        player->rect().x = physics.getX();
        player->rect().y = physics.getY();
        float rectX= player->rect().x;
        float rectY= player->rect().y;
        float rectW= player->rect().w;
        float rectH= player->rect().h;
        

        bool isMoving = (std::abs(input.x) > 0.1f);

    player->update(deltaTime, input.x != 0 || input.y != 0, PhysicsBody(rectX, rectY, rectW, rectH));

        manager.handleCollisions();
        manager.updateAll(deltaTime);

        // 🎨 Render
        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_RenderClear(renderer);

        joystick.render(renderer);
        manager.renderAll(renderer);
        // 🧱 Dibujar suelo
        SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
        SDL_RenderDrawLine(renderer, 0, (int)screenH  * 0.95f, screenW , (int)screenH * 0.95f);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}