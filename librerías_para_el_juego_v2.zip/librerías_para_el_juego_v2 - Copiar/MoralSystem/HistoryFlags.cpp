#include "StoryFlags.h"

void StoryFlags::setFlag(const std::string& flagName, bool value) {
    flags[flagName] = value;
}

bool StoryFlags::isFlagSet(const std::string& flagName) const {
    auto it = flags.find(flagName);
    return it != flags.end() && it->second;
}

void StoryFlags::clearFlag(const std::string& flagName) {
    flags.erase(flagName);
}

const std::unordered_map<std::string, bool>& StoryFlags::getAllFlags() const {
    return flags;
}

void StoryFlags::loadFlags(const std::unordered_map<std::string, bool>& externalFlags) {
    flags = externalFlags;
}