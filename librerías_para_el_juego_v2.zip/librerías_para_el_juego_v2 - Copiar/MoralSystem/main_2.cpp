#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/MoralSystem/NarrativeEvent.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/MoralSystem/NarrativeEvent.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PlayerStats/PlayerStats.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PlayerStats/PlayerStats.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/MoralSystem/MoralSystem.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/MoralSystem/MoralSystem.cpp"
#include <iostream>

std::string evaluateEnding(const PlayerStats& stats) {
    if (stats.determination > stats.evilnessLevel &&
        stats.determination > stats.goodnessLevel)
        return "Final Bueno";

    if (stats.evilnessLevel > stats.determination &&
        stats.evilnessLevel > stats.goodnessLevel)
        return "Final Malvado";

    if (stats.goodnessLevel > stats.determination &&
        stats.goodnessLevel > stats.evilnessLevel)
        return "Final Ingenuo";

    return "Final Neutro";
}

int main() {
    PlayerStats stats;
    MoralSystem moral;

    NarrativeEvent event(
        "Un enemigo herido te suplica ayuda.",
        {"Ayudarlo con compasión", MoralType::Wise, 10},
        {"Ignorarlo y seguir", MoralType::Indifferent, 5},
        {"Atacarlo sin piedad", MoralType::Impulsive, 10}
    );

    event.present();

    int choice;
    std::cout << "Elige una opción (1-3): ";
    std::cin >> choice;

    event.chooseOption(choice, stats, moral);

    std::cout << "\n📊 Determinación: " << stats.determination << "\n";
    std::cout << "😈 Maldad: " << stats.evilnessLevel << "\n";
    std::cout << "😇 Bondad: " << stats.goodnessLevel << "\n";

    std::string ending = evaluateEnding(stats);
    std::cout << "\n🔚 Final proyectado: " << ending << "\n";

    return 0;
}