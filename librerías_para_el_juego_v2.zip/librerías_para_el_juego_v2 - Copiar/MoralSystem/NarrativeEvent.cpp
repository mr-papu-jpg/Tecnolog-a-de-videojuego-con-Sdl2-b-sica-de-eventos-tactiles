#include "NarrativeEvent.h"
#include <iostream>

NarrativeEvent::NarrativeEvent(const std::string& description,
                               const NarrativeOption& wise,
                               const NarrativeOption& impulsive,
                               const NarrativeOption& indifferent)
    : description_(description) {
    options_[0] = wise;
    options_[1] = impulsive;
    options_[2] = indifferent;
}

void NarrativeEvent::present() {
    std::cout << "\n📜 Evento: " << description_ << "\n";
    std::cout << "1. 🟨 " << options_[0].text << "\n";
    std::cout << "2. 🟥 " << options_[1].text << "\n";
    std::cout << "3. 🟦 " << options_[2].text << "\n";
}

void NarrativeEvent::chooseOption(int index, PlayerStats& stats, MoralSystem& moral) {
    if (index < 1 || index > 3) return;

    NarrativeOption& choice = options_[index - 1];

    // Aplicar efecto moral
    moral.registerDecision({choice.text, choice.type, choice.impactScore});

    // Aplicar efecto en atributos
    switch (choice.type) {
        case MoralType::Wise:
            stats.determination += choice.impactScore;
            break;
        case MoralType::Impulsive:
            stats.evilnessLevel += choice.impactScore;
            stats.attack += 2;
            break;
        case MoralType::Indifferent:
            stats.goodnessLevel += choice.impactScore;
            break;
    }

    std::cout << "Has elegido: " << choice.text << "\n";
}