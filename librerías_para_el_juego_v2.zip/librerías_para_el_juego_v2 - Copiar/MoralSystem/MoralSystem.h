#ifndef MORAL_SYSTEM_H
#define MORAL_SYSTEM_H

#include <vector>
#include <string>
#include <map>

enum class MoralType {
    Wise,       // Equilibrado, reflexivo
    Impulsive,  // Actúa sin pensar
    Indifferent // Evita tomar decisiones
};

struct MoralDecision {
    std::string description;
    MoralType type;
    int impactScore; // Puede ser positivo o negativo
};

class MoralSystem {
public:
    MoralSystem();

    void registerDecision(const MoralDecision& decision);
    MoralType evaluateDominantMoral() const;
    int getTotalScore() const;
    std::map<MoralType, int> getMoralBreakdown() const;

private:
    std::vector<MoralDecision> decisions;
    std::map<MoralType, int> moralScores;
};

#endif // MORAL_SYSTEM_H