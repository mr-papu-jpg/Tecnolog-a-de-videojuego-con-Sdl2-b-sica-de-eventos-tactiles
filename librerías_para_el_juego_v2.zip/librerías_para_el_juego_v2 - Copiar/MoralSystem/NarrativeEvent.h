#pragma once
#include <string>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PlayerStats/PlayerStats.h"
#include "MoralSystem.h"

struct NarrativeOption {
    std::string text;
    MoralType type;
    int impactScore;
};

class NarrativeEvent {
public:
    NarrativeEvent(const std::string& description,
                   const NarrativeOption& wise,
                   const NarrativeOption& impulsive,
                   const NarrativeOption& indifferent);

    void present();
    void chooseOption(int index, PlayerStats& stats, MoralSystem& moral);

private:
    std::string description_;
    NarrativeOption options_[3];
};