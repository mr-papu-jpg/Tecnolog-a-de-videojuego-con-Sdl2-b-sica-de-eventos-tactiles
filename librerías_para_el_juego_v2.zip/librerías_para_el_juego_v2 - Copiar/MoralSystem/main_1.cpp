#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/MoralSystem/MoralSystem.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/MoralSystem/MoralSystem.cpp"
#include <iostream>

std::string moralToString(MoralType type) {
    switch (type) {
        case MoralType::Wise: return "Sabio";
        case MoralType::Impulsive: return "Impulsivo";
        case MoralType::Indifferent: return "Indiferente";
        default: return "Desconocido";
    }
}

int main() {
    MoralSystem moral;

    moral.registerDecision({"Ayudó a un enemigo", MoralType::Wise, 10});
    moral.registerDecision({"Ignoró a un amigo", MoralType::Indifferent, -5});
    moral.registerDecision({"Atacó sin pensar", MoralType::Impulsive, -3});

    MoralType dominant = moral.evaluateDominantMoral();
    std::cout << "Moral dominante: " << moralToString(dominant) << "\n";

    auto breakdown = moral.getMoralBreakdown();
    for (const auto& [type, score] : breakdown) {
        std::cout << moralToString(type) << ": " << score << "\n";
    }

    return 0;
}