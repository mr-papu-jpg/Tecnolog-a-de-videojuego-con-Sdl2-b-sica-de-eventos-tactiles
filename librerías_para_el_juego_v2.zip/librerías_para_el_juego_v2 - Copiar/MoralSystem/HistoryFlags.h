#ifndef STORY_FLAGS_H
#define STORY_FLAGS_H

#include <unordered_map>
#include <string>

class StoryFlags {
public:
    // Activa una bandera narrativa
    void setFlag(const std::string& flagName, bool value = true);

    // Consulta si una bandera está activa
    bool isFlagSet(const std::string& flagName) const;

    // Elimina una bandera (opcional)
    void clearFlag(const std::string& flagName);

    // Devuelve todas las banderas activas (para guardar)
    const std::unordered_map<std::string, bool>& getAllFlags() const;

    // Carga banderas desde un mapa externo (para cargar partida)
    void loadFlags(const std::unordered_map<std::string, bool>& flags);

private:
    std::unordered_map<std::string, bool> flags;
};

#endif // STORY_FLAGS_H