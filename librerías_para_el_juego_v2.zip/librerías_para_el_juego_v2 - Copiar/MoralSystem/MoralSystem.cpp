#include "MoralSystem.h"

MoralSystem::MoralSystem() {
    moralScores[MoralType::Wise] = 0;
    moralScores[MoralType::Impulsive] = 0;
    moralScores[MoralType::Indifferent] = 0;
}

void MoralSystem::registerDecision(const MoralDecision& decision) {
    decisions.push_back(decision);
    moralScores[decision.type] += decision.impactScore;
}

MoralType MoralSystem::evaluateDominantMoral() const {
    int wiseScore = moralScores.at(MoralType::Wise);
    int impulsiveScore = moralScores.at(MoralType::Impulsive);
    int indifferentScore = moralScores.at(MoralType::Indifferent);

    if (wiseScore >= impulsiveScore && wiseScore >= indifferentScore)
        return MoralType::Wise;
    else if (impulsiveScore >= wiseScore && impulsiveScore >= indifferentScore)
        return MoralType::Impulsive;
    else
        return MoralType::Indifferent;
}

int MoralSystem::getTotalScore() const {
    int total = 0;
    for (const auto& [type, score] : moralScores) {
        total += score;
    }
    return total;
}

std::map<MoralType, int> MoralSystem::getMoralBreakdown() const {
    return moralScores;
}