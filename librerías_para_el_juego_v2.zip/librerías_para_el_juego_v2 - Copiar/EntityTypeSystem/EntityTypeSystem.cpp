#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/EntityTypeSystem/EntityTypeSystem.h"

EntityTraits::EntityTraits(EntityType type)
    : type_(type), name_("Unknown"), tag_("none") {}

void EntityTraits::setName(const std::string& name) { name_ = name; }
void EntityTraits::setTag(const std::string& tag) { tag_ = tag; }

EntityType EntityTraits::getType() const { return type_; }
const std::string& EntityTraits::getName() const { return name_; }
const std::string& EntityTraits::getTag() const { return tag_; }

bool EntityTraits::isDamageable() const {
    return type_ == EntityType::Player || type_ == EntityType::Enemy;
}

bool EntityTraits::isMovable() const {
    return type_ == EntityType::Player || type_ == EntityType::Movable || type_ == EntityType::Enemy || type_ == EntityType::Projectile;
}

bool EntityTraits::isInteractable() const {
    return type_ == EntityType::Interactable;
}