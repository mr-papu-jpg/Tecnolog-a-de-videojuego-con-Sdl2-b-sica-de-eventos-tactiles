#pragma once
#include <string>

enum class EntityType {
    Player,
    Enemy,
    Movable,
    Interactable,
    Static,
    Projectile
};

class EntityTraits {
public:
    EntityTraits(EntityType type);

    void setName(const std::string& name);
    void setTag(const std::string& tag); // útil para lógica específica

    EntityType getType() const;
    const std::string& getName() const;
    const std::string& getTag() const;

    bool isDamageable() const;
    bool isMovable() const;
    bool isInteractable() const;

private:
    EntityType type_;
    std::string name_;
    std::string tag_;
};