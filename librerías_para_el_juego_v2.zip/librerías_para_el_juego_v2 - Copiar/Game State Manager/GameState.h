#pragma once
#include <SDL2/SDL.h>

class GameState {
public:
    virtual ~GameState() = default;
    virtual void enter() {}
    virtual void exit() {}
    virtual void pause() {}
    virtual void resume() {}
    virtual void handleEvent(const SDL_Event& e) = 0;
    virtual void update() = 0;
    virtual void render(SDL_Renderer* renderer) = 0;
};