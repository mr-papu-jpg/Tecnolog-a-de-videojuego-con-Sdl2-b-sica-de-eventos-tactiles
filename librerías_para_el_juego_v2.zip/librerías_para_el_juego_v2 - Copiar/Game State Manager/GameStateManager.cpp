// GameStateManager.hpp
#pragma once
#include "GameState.h"
#include <stack>
#include <memory>

class GameStateManager {
    std::stack<std::unique_ptr<GameState>> states_;

public:
    void pushState(std::unique_ptr<GameState> state) {
        if (!states_.empty()) states_.top()->pause();
        state->enter();
        states_.push(std::move(state));
    }

    void popState() {
        if (!states_.empty()) {
            states_.top()->exit();
            states_.pop();
        }
        if (!states_.empty()) states_.top()->resume();
    }

    void changeState(std::unique_ptr<GameState> state) {
        popState();
        pushState(std::move(state));
    }

    void handleEvent(const SDL_Event& e) {
        if (!states_.empty()) states_.top()->handleEvent(e);
    }

    void update() {
        if (!states_.empty()) states_.top()->update();
    }

    void render(SDL_Renderer* renderer) {
        if (!states_.empty()) states_.top()->render(renderer);
    }
};