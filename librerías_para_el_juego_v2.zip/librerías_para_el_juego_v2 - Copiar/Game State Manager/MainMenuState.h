#pragma once
#include "GameState.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <vector>
#include <string>

struct MenuButton {
    SDL_Texture* texture = nullptr;
    SDL_Rect rect;
    std::string label;
    bool pressed = false;

    void set(SDL_Texture* tex, int x, int y, int w, int h, const std::string& name) {
        texture = tex;
        rect = {x, y, w, h};
        label = name;
    }

    bool isTouched(float tx, float ty) const {
        return tx >= rect.x && tx <= rect.x + rect.w &&
               ty >= rect.y && ty <= rect.y + rect.h;
    }

    void render(SDL_Renderer* renderer) const {
        if (texture) SDL_RenderCopy(renderer, texture, nullptr, &rect);
    }
};

class MainMenuState : public GameState {
    SDL_Renderer* renderer_;
    std::vector<MenuButton> buttons_;
    int screenW_ = 800;
    int screenH_ = 600;

    // 🔴 Rectángulo rojo
    bool showRedRect_ = false;
    SDL_Rect redRect_ = {100, 100, 100, 100};

    // 🟢 Punto de depuración táctil
    bool showTouchPoint_ = false;
    int touchX_ = 0;
    int touchY_ = 0;

public:
    MainMenuState(SDL_Renderer* renderer) : renderer_(renderer) {
        // Obtener tamaño real del renderer
        SDL_GetRendererOutputSize(renderer_, &screenW_, &screenH_);
    }

    void enter() override {
        // Cargar texturas de botones
        SDL_Texture* jugarTex = IMG_LoadTexture(renderer_, "/storage/3807-15EE/DCIM/frames/StartButton.png");
        SDL_Texture* ajustesTex = IMG_LoadTexture(renderer_, "/storage/3807-15EE/DCIM/frames/sentings.png");
        SDL_Texture* creditosTex = IMG_LoadTexture(renderer_, "/storage/3807-15EE/DCIM/frames/credist.png");

        buttons_.resize(3);
        buttons_[0].set(jugarTex, 300, 150, 200, 80, "Jugar");
        buttons_[1].set(ajustesTex, 300, 250, 200, 80, "Ajustes");
        buttons_[2].set(creditosTex, 300, 350, 200, 80, "Créditos");
    }

    void handleEvent(const SDL_Event& e) override {
        if (e.type == SDL_FINGERDOWN) {
            float tx = e.tfinger.x * screenW_;
            float ty = e.tfinger.y * screenH_;

            touchX_ = static_cast<int>(tx);
            touchY_ = static_cast<int>(ty);
            showTouchPoint_ = true;

            SDL_Log("Toque en: x=%f, y=%f", tx, ty);

            for (auto& btn : buttons_) {
                if (btn.isTouched(tx, ty)) {
                    btn.pressed = true;
                    SDL_Log("Botón tocado: %s", btn.label.c_str());
                    showRedRect_ = true;
                }
            }
        }

        if (e.type == SDL_FINGERUP) {
            showTouchPoint_ = false;
        }
    }

    void update() override {
        // Lógica adicional si se desea
    }

    void render(SDL_Renderer* renderer) override {
        SDL_SetRenderDrawColor(renderer, 20, 20, 20, 255);
        SDL_RenderClear(renderer);

        for (const auto& btn : buttons_) {
            btn.render(renderer);
        }

        // 🔴 Dibujar rectángulo rojo si está activo
        if (showRedRect_) {
            SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
            SDL_RenderFillRect(renderer, &redRect_);
        }

        // 🟢 Dibujar punto verde de depuración táctil
        if (showTouchPoint_) {
            SDL_Rect touchPoint = { touchX_ - 2, touchY_ - 2, 4, 4 };
            SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
            SDL_RenderFillRect(renderer, &touchPoint);
        }

        SDL_RenderPresent(renderer);
    }
};