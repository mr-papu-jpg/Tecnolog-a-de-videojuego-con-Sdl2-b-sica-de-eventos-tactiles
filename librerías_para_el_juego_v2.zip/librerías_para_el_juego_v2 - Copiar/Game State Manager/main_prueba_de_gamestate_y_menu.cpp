#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Game State Manager/GameStateManager.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Game State Manager/MainMenuState.h"

int main(int argc, char* argv[]) {
    // Inicialización de SDL
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS);
    IMG_Init(IMG_INIT_PNG);

    const int screenW = 800;
    const int screenH = 600;

    SDL_Window* window = SDL_CreateWindow("Prueba Main Menu",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        screenW, screenH, SDL_WINDOW_SHOWN);

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    if (!window || !renderer) {
        SDL_Log("Error al crear ventana o renderizador: %s", SDL_GetError());
        return 1;
    }

    // Crear el gestor de estados y cargar el menú principal
    GameStateManager gsm;
    gsm.pushState(std::make_unique<MainMenuState>(renderer));

    bool running = true;
    SDL_Event event;

    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT)
                running = false;

            gsm.handleEvent(event);
        }

        gsm.update();
        gsm.render(renderer);
        SDL_Delay(16); // ~60 FPS
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();
    return 0;
}