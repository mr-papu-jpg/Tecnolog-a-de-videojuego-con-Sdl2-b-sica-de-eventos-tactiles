// TestState.hpp
#pragma once
#include "GameState.h"

class TestState : public GameState {
    bool pressed_ = false;
    SDL_Rect rect_ = {100, 100, 50, 50};

public:
    void handleEvent(const SDL_Event& e) override {
        if (e.type == SDL_MOUSEBUTTONDOWN) {
            SDL_Log("Mouse button pressed in TestState");
            pressed_ = true;
        }
    }

    void update() override {
        if (pressed_) rect_.x += 5;
    }

    void render(SDL_Renderer* renderer) override {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
        SDL_RenderFillRect(renderer, &rect_);

        SDL_RenderPresent(renderer);
    }
};