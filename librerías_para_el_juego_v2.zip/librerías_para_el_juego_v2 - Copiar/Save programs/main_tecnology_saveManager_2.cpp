#include <iostream>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Save programs/SaveManager.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Save programs/SaveManager.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Save programs/json.hpp"

int main() {
    // 📁 Directorio donde se guardarán los archivos JSON
    SaveManager manager("saves");

    // 📝 Crear datos de prueba
    SaveData data;
    data.playerName = "Angel";
    data.levelID = 1;
    data.posX = 120.5f;
    data.posY = 300.0f;
    data.playTime = 45.3;

    // 💾 Guardar en el slot 0
    if (manager.saveToSlot(0, data)) {
        std::cout << "Partida guardada exitosamente en el slot 0.\n";
    } else {
        std::cerr << "Error al guardar la partida.\n";
    }

    // 📤 Cargar desde el slot 0
    auto loaded = manager.loadFromSlot(0);
    if (loaded) {
        std::cout << "Partida cargada:\n";
        std::cout << "Jugador: " << loaded->playerName << "\n";
        std::cout << "Nivel: " << loaded->levelID << "\n";
        std::cout << "Posición: (" << loaded->posX << ", " << loaded->posY << ")\n";
        std::cout << "Tiempo jugado: " << loaded->playTime << " segundos\n";
    } else {
        std::cerr << "No se pudo cargar la partida del slot 0.\n";
    }

    return 0;
}