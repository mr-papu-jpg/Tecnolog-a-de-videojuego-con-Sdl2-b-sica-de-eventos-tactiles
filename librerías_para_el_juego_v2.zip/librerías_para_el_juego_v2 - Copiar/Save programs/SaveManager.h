#pragma once
#include <string>
#include <optional>

#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/MoralSystem/HistoryFlags.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PlayerStats/AbilitySystem.h"

struct SaveData {
    std::string playerName;
    int levelID;
    float posX, posY;
    double playTime;
    PlayerStats stats;
    StoryFlags storyFlags;
    AbilitySystem abilitySystem;
};

class SaveManager {
public:
    static const int MAX_SLOTS = 3;

    SaveManager(const std::string& saveDirectory);

    bool saveToSlot(int slotIndex, const SaveData& data);
    std::optional<SaveData> loadFromSlot(int slotIndex);
    bool deleteSlot(int slotIndex);
    bool slotExists(int slotIndex) const;

private:
    std::string getSlotPath(int slotIndex) const;
    std::string saveDirectory;
};