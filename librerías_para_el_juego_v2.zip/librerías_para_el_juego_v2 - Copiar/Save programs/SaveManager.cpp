#include "SaveManager.h"
#include "json.hpp"
#include <fstream>
#include <filesystem>

using json = nlohmann::json;

SaveManager::SaveManager(const std::string& dir) : saveDirectory(dir) {
    std::filesystem::create_directories(saveDirectory);
}

std::string SaveManager::getSlotPath(int slotIndex) const {
    return saveDirectory + "/slot" + std::to_string(slotIndex) + ".json";
}

bool SaveManager::saveToSlot(int slotIndex, const SaveData& data) {
    if (slotIndex < 0 || slotIndex >= MAX_SLOTS) return false;

    json j;
    j["playerName"] = data.playerName;
    j["levelID"] = data.levelID;
    j["posX"] = data.posX;
    j["posY"] = data.posY;
    j["playTime"] = data.playTime;
    j["stats"] = data.stats.toJson();
    j["abilities"] = data.abilitySystem.toJson();

    // 🔗 Guardar StoryFlags
    json flagsJson;
    for (const auto& [key, value] : data.storyFlags.getAllFlags()) {
        flagsJson[key] = value;
    }
    j["storyFlags"] = flagsJson;

    std::ofstream out(getSlotPath(slotIndex));
    if (!out) return false;

    out << j.dump(4);
    return true;
}

std::optional<SaveData> SaveManager::loadFromSlot(int slotIndex) {
    if (!slotExists(slotIndex)) return std::nullopt;

    std::ifstream in(getSlotPath(slotIndex));
    if (!in) return std::nullopt;

    json j;
    in >> j;

    SaveData data;
    data.playerName = j.value("playerName", "Unknown");
    data.levelID = j.value("levelID", 0);
    data.posX = j.value("posX", 0.0f);
    data.posY = j.value("posY", 0.0f);
    data.playTime = j.value("playTime", 0.0);
    data.stats.fromJson(j["stats"]);
     data.abilitySystem.fromJson(j["abilities"]);

    // 🔗 Cargar StoryFlags
    std::unordered_map<std::string, bool> loadedFlags;
    for (auto& [key, value] : j["storyFlags"].items()) {
        loadedFlags[key] = value.get<bool>();
    }
    data.storyFlags.loadFlags(loadedFlags);

    return data;
}

bool SaveManager::deleteSlot(int slotIndex) {
    return std::filesystem::remove(getSlotPath(slotIndex));
}

bool SaveManager::slotExists(int slotIndex) const {
    return std::filesystem::exists(getSlotPath(slotIndex));
}