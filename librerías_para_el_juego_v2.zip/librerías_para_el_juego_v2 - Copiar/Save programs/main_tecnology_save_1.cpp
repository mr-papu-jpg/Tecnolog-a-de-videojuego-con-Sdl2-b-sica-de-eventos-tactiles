#include <iostream>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Save programs/json.hpp"
using json = nlohmann::json;

int main() {
    json j;
    j["name"] = "Angel";
    j["level"] = 1;

    std::cout << j.dump(4) << std::endl;
    return 0;
}