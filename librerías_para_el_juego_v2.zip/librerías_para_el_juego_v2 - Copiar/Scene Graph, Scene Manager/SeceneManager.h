#pragma once
#include "Scene.h"
#include "FadeTransitionScene.h"

class SceneManager {
    Scene* currentScene_ = nullptr;

public:
    ~SceneManager() {
        if (currentScene_) delete currentScene_;
    }

    void setScene(Scene* scene, bool useTransition = false) {
        if (useTransition && currentScene_) {
            currentScene_ = new FadeTransitionScene(currentScene_, scene);
        } else {
            if (currentScene_) delete currentScene_;
            currentScene_ = scene;
            currentScene_->enter();
        }
    }

    void handleEvent(const SDL_Event& e) {
        if (currentScene_) currentScene_->handleEvent(e);
    }

    void update(float deltaTime) {
        if (currentScene_) {
            currentScene_->update(deltaTime);
            if (currentScene_->isFinished()) {
                Scene* next = currentScene_->nextScene();
                if (next) setScene(next, true); // transición automática
            }
        }
    }

    void render(SDL_Renderer* renderer) {
        if (currentScene_) currentScene_->render(renderer);
    }
};