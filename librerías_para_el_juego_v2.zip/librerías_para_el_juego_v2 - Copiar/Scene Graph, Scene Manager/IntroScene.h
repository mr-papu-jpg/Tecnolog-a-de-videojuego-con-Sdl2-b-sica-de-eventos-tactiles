#pragma once
#include "Scene.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

class IntroScene : public Scene {
    SDL_Texture* texture_ = nullptr;
    SDL_Renderer* renderer_;
    Uint32 startTime_ = 0;
    Uint32 duration_ = 3000; // 3 segundos
    bool finished_ = false;

public:
    IntroScene(SDL_Renderer* renderer) : renderer_(renderer) {}

    void enter() override {
        texture_ = IMG_LoadTexture(renderer_, "assets/intro_pixelart.png");
        startTime_ = SDL_GetTicks();
    }

    void handleEvent(const SDL_Event&) override {}

    void update(float) override {
        if (SDL_GetTicks() - startTime_ > duration_) {
            finished_ = true;
        }
    }

    void render(SDL_Renderer* renderer) override {
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        if (texture_) SDL_RenderCopy(renderer, texture_, nullptr, nullptr);
        SDL_RenderPresent(renderer);
    }

    bool isFinished() const override { return finished_; }

    Scene* nextScene() const override {
        return nullptr; // Aquí luego pondrás tu sistema de niveles
    }

    ~IntroScene() {
        if (texture_) SDL_DestroyTexture(texture_);
    }
};