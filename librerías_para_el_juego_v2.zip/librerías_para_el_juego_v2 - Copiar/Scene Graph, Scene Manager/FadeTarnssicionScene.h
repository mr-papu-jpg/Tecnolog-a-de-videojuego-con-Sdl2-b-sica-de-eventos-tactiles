#pragma once
#include "Scene.h"

class FadeTransitionScene : public Scene {
    Scene* from_;
    Scene* to_;
    Uint32 startTime_;
    Uint32 duration_ = 1000; // 1 segundo
    bool entered_ = false;

public:
    FadeTransitionScene(Scene* from, Scene* to)
        : from_(from), to_(to), startTime_(SDL_GetTicks()) {}

    void enter() override {
        entered_ = true;
    }

    void handleEvent(const SDL_Event&) override {}

    void update(float) override {
        if (SDL_GetTicks() - startTime_ > duration_) {
            finished = true;
        }
    }

    void render(SDL_Renderer* renderer) override {
        if (!entered_) enter();

        // Render escena anterior
        if (from_) from_->render(renderer);

        // Dibujar fade overlay
        Uint8 alpha = static_cast<Uint8>(255.0f * ((SDL_GetTicks() - startTime_) / (float)duration_));
        SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, alpha);
        SDL_Rect screen = {0, 0, 800, 600}; // ajusta según resolución
        SDL_RenderFillRect(renderer, &screen);
    }

    Scene* nextScene() const override {
        if (to_) to_->enter();
        return to_;
    }

    ~FadeTransitionScene() {
        if (from_) delete from_;
    }
};