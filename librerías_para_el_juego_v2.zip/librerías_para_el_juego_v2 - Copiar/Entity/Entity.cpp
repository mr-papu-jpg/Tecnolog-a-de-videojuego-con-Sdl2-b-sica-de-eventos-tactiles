#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/colisionsUtils.h"

Entity::Entity(float x, float y, float w, float h, SDL_Texture* texture, EntityType type)
    : animator_(texture), traits_(type), physics_(x, y, w, h) {}

void Entity::update(float dt) {
    physics_.update(dt);
    animator_.update(dt);
}

void Entity::render(SDL_Renderer* renderer) {
    const SDL_FRect& rect = physics_.getRect();
    animator_.render(renderer, rect.x, rect.y);
}

void Entity::setVelocity(float vx, float vy) {
    physics_.setVelocity(vx, vy);
}

void Entity::setGravity(float g) {
    physics_.setGravity(g);
}

void Entity::setGround(float y) {
    physics_.setGround(y);
}

bool Entity::isGrounded() const {
    return physics_.isGrounded();
}

bool Entity::checkCollision(const Entity& other) const {
    return physics_.collidesWith(other.physics_);
}

void Entity::constrainToBounds(int screenW, int screenH) {
    physics_.constrainToBounds(screenW, screenH);
}

SpriteAnimator& Entity::getAnimator() {
    return animator_;
}

EntityTraits& Entity::getTraits() {
    return traits_;
}

PhysicsBody& Entity::getPhysics() {
    return physics_;
}

SDL_FRect Entity::getRect() const {
    return physics_.getRect();
}

void Entity::applyJoystickInput(const SDL_FPoint& direction, float speed) {
    physics_.setVelocity(direction.x*speed,physics_.getVelocity().y);
}

bool Entity::checkCollisionWith(const Entity& other) const {
    return physics_.collidesWith(other.physics_);
}

SDL_FPoint Entity::getVelocity() const{
    return physics_.getVelocity();
}

const EntityTraits& Entity::getTraits() const {
    return traits_;
}