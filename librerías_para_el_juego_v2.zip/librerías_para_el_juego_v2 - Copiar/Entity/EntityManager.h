#pragma once
#include <vector>
#include <memory>
#include <SDL2/SDL.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.h"

class EntityManager {
public:
    void addEntity(std::shared_ptr<Entity> entity);
    
    void updateAll(float dt);
    void renderAll(SDL_Renderer* renderer);
    void handleCollisions(); // usa tags y tipos
    void removeByTag(const std::string& tag);

    const std::vector<std::shared_ptr<Entity>>& getEntities() const;

private:
    std::vector<std::shared_ptr<Entity>> entities_;
};