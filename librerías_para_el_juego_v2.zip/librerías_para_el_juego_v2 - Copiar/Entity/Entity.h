#pragma once
#include <SDL2/SDL.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/EntityTypeSystem/EntityTypeSystem.h"

class Entity {
public:
    Entity(float x, float y, float w, float h, SDL_Texture* texture, EntityType type);

    void update(float dt);
    void render(SDL_Renderer* renderer);

    void setVelocity(float vx, float vy);
    void setGravity(float g);
    void setGround(float y);

    bool isGrounded() const;
    bool checkCollision(const Entity& other) const;

    void constrainToBounds(int screenW, int screenH);

    SpriteAnimator& getAnimator();
    EntityTraits& getTraits();
    const EntityTraits& getTraits() const; // ✅ versión const
    PhysicsBody& getPhysics();
void applyJoystickInput(const SDL_FPoint& direction, float speed);
    SDL_FRect getRect() const;
bool checkCollisionWith(const Entity& other) const;
SDL_FPoint getVelocity() const;

private:
    SpriteAnimator animator_;
    EntityTraits traits_;
    PhysicsBody physics_;
};
