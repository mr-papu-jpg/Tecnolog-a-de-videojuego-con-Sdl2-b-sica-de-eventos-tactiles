#pragma once
#include <SDL2/SDL.h>

inline bool SDL_HasIntersectionF(const SDL_FRect* A, const SDL_FRect* B) {
    return !(B->x >= (A->x + A->w) ||
             (B->x + B->w) <= A->x ||
             B->y >= (A->y + A->h) ||
             (B->y + B->h) <= A->y);
}

// Devuelve el rectángulo de intersección entre A y B
inline SDL_FRect SDL_GetIntersectionF(const SDL_FRect* A, const SDL_FRect* B) {
    SDL_FRect result;

    float x1 = std::max(A->x, B->x);
    float y1 = std::max(A->y, B->y);
    float x2 = std::min(A->x + A->w, B->x + B->w);
    float y2 = std::min(A->y + A->h, B->y + B->h);

    if (x2 > x1 && y2 > y1) {
        result.x = x1;
        result.y = y1;
        result.w = x2 - x1;
        result.h = y2 - y1;
    } else {
        result = {0, 0, 0, 0}; // No hay intersección
    }

    return result;
}

// Detecta si A está completamente dentro de B
inline bool SDL_IsInsideF(const SDL_FRect* A, const SDL_FRect* B) {
    return (A->x >= B->x &&
            A->y >= B->y &&
            (A->x + A->w) <= (B->x + B->w) &&
            (A->y + A->h) <= (B->y + B->h));
}