#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/EntityManager.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/colisionsUtils.h"

void EntityManager::addEntity(std::shared_ptr<Entity> entity) {
    entities_.push_back(entity);
}

void EntityManager::updateAll(float dt) {
    for (auto& e : entities_) {
        // Puedes ajustar condiciones externas aquí si lo deseas
        e->update(dt, true, PhysicsBody(e->rect().x, e->rect().y, e->rect().w, e->rect().h));
    }
}

void EntityManager::renderAll(SDL_Renderer* renderer) {
    for (auto& e : entities_) {
        e->render(renderer);
    }
}

void EntityManager::handleCollisions() {
    for (size_t i = 0; i < entities_.size(); ++i) {
        for (size_t j = i + 1; j < entities_.size(); ++j) {
            auto& a = entities_[i];
            auto& b = entities_[j];

            if (a->checkCollisionWith(*b)) {
                auto typeA = a->traits().getType();
                auto typeB = b->traits().getType();

                // Ejemplos de lógica por tipo
                if (typeA == EntityType::Player && typeB == EntityType::Enemy) {
                    a->traits().setTag("Hit");
                    b->traits().setTag("Collided");
                }
                if (typeA == EntityType::Projectile && b->traits().isDamageable()) {
                    b->traits().setTag("Damaged");
                    a->traits().setTag("Consumed");
                }
            }
        }
    }
}

void EntityManager::removeByTag(const std::string& tag) {
    entities_.erase(
        std::remove_if(entities_.begin(), entities_.end(),
            [&](const std::shared_ptr<Entity>& e) {
                return e->traits().getTag() == tag;
            }),
        entities_.end()
    );
}

const std::vector<std::shared_ptr<Entity>>& EntityManager::getEntities() const {
    return entities_;
}